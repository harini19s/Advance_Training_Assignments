package day2;
import java.io.*;

import java.util.*;

public class array_manipulation 
{

  static void findFrequency(int [] arr, 

                            int n)

  {

    Map<Integer, Integer> mp 

      = new HashMap<Integer, Integer>(); 
 
    for (int i = 0; i < n; i++) 

    { 
 

      // update the frequency

      if (!mp.containsKey(arr[i]))

        mp.put(arr[i],0);
 

      mp.put(arr[i],mp.get(arr[i])+1);

    }


    for (Map.Entry<Integer, Integer> kvp : mp.entrySet())

    {

      System.out.println("Element " + kvp.getKey() + 

                         " occurs " + kvp.getValue() +

                         " times");

    }
  }

  public static void main (String[] args) {
 
 

    int [] arr = {1, 1, 1, 2, 

                  3, 3, 5, 5,

                  8, 8, 8, 9, 

                  9, 10};

    int n = arr.length;

    findFrequency(arr, n);

  }}